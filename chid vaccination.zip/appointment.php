<?php
session_start();
include("connection.php");

// Check login and role
if (!isset($_SESSION['user']['id']) || $_SESSION['user']['role'] != 'parent') {
    echo "You must be logged in as a parent to book an appointment.";
    exit();
}

$user_id = $_SESSION['user']['id'];  // Parent's user ID

// Get anganwadi_id (hospital) for the logged-in parent
$query = "SELECT anganwadi_id FROM users WHERE id = $user_id AND role = 'parent'";
$result = mysqli_query($connection, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $data = mysqli_fetch_assoc($result);
    $hospital_id = $data['anganwadi_id']; // ID of the linked Anganwadi center

    // If form submitted
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $childName = trim($_POST['childName']);
        $vaccineName = trim($_POST['vaccineName']);
        $vaccineDose = trim($_POST['vaccineDose']);
        $appointmentDate = $_POST['appointmentDate'];
        $appointmentTime = $_POST['appointmentTime'];
        $centerName = $_POST['centerName'];
        $street = $_POST['street'];
        $city = $_POST['city'];
        $state = $_POST['state'];
        $pincode = isset($_POST['pincode']) ? $_POST['pincode'] : null;
        $status = 'Pending';

        // Insert into appointments
        $stmt = $connection->prepare("INSERT INTO appointments (parent_id, anganwadi_id, child_name, vaccine_name, vaccine_dose, appointment_date, appointment_time, center_name, street, city, state, pincode, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("iisssssssssss", $user_id, $hospital_id, $childName, $vaccineName, $vaccineDose, $appointmentDate, $appointmentTime, $centerName, $street, $city, $state, $pincode, $status);

        if ($stmt->execute()) {
            echo "<script>alert('✅ Appointment booked successfully!');</script>";
        } else {
            echo "<script>alert('❌ Error booking appointment: " . $stmt->error . "');</script>";
        }

        $stmt->close();
    }

} else {
    echo "❌ Hospital (Anganwadi center) not linked with this parent!";
    exit();
}

// Fetch dropdown options for the form
function fetchUniqueValues($column) {
    global $connection;
    $query = "SELECT DISTINCT $column FROM anganwadi_centers WHERE $column IS NOT NULL";
    $result = mysqli_query($connection, $query);
    
    if (!$result) {
        echo "Error fetching $column data: " . mysqli_error($connection);
        return [];
    }

    $values = [];
    while ($row = mysqli_fetch_assoc($result)) {
        $values[] = $row[$column];
    }

    return $values;
}

$centerNames = fetchUniqueValues('name');
$streets = fetchUniqueValues('street');
$cities = fetchUniqueValues('city');
$states = fetchUniqueValues('state');
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Appointment Booking - Child Vaccination</title>
    <link rel="stylesheet" href="commamcss.css" />
    <!-- <link rel="stylesheet" href="footer.css"/> -->
    <style>
        h2 {
            color: #007bff;
        }
        label {
            font-weight: bold;
            display: block;
            margin-top: 10px;
        }
        input, select {
            width: 80%;
            padding: 8px;
            margin: 5px 0;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
        }
        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: center;
        }
        th {
            background-color: #007bff;
            color: white;
        }
        .delete-btn {
            background: red;
            color: white;
            border: none;
            padding: 5px 10px;
            cursor: pointer;
            border-radius: 5px;
        }
        .delete-btn:hover {
            background: darkred;
        }
    </style>
</head>
<body>
    <header class="header">Book Vaccination Appointment</header>
    <nav>
    <a href="anganwadi-details.php">Anganwadi</a>
    <a href="showvaccine.php">Vaccine Details</a>
    <a href="appointment.php">Appointment</a>
    <a href="schedule.php">Schedule</a>
    <a href="profile.php">profile</a>
    <a href="logout.php">logout</a>
  
    </nav>
    <div class="container">
        <form action="appointment.php" method="POST">
            <label for="childName">Child's Name:</label>
            <input type="text" name="childName" required>
        
            <label for="vaccineName">Vaccine Name:</label>
            <input type="text" name="vaccineName" required>
        
            <label for="vaccineDose">Vaccine Dose:</label>
            <input type="text" name="vaccineDose" required>
        
            <label for="appointmentDate">Appointment Date:</label>
            <input type="date" name="appointmentDate" required>
        
            <label for="appointmentTime">Appointment Time:</label>
            <input type="time" name="appointmentTime" required>
        
            <label for="centerName">Center Name:</label>
            <select name="centerName" required>
                <option value="">--Select--</option>
                <?php foreach ($centerNames as $center) : ?>
                    <option value="<?= htmlspecialchars($center) ?>"><?= htmlspecialchars($center) ?></option>
                <?php endforeach; ?>
            </select>
        
            <label for="street">Street:</label>
            <select name="street" required>
                <option value="">--Select--</option>
                <?php foreach ($streets as $street) : ?>
                    <option value="<?= htmlspecialchars($street) ?>"><?= htmlspecialchars($street) ?></option>
                <?php endforeach; ?>
            </select>
        
            <label for="city">City:</label>
            <select name="city" required>
                <option value="">--Select--</option>
                <?php foreach ($cities as $city) : ?>
                    <option value="<?= htmlspecialchars($city) ?>"><?= htmlspecialchars($city) ?></option>
                <?php endforeach; ?>
            </select>
        
            <label for="state">State:</label>
            <select name="state" required>
                <option value="">--Select--</option>
                <?php foreach ($states as $state) : ?>
                    <option value="<?= htmlspecialchars($state) ?>"><?= htmlspecialchars($state) ?></option>
                <?php endforeach; ?>
            </select>
        
            <label for="pincode">Pincode:</label>
            <input type="text" name="pincode"  pattern="\d{6}" title="Please enter a valid 6-digit pincode.">
        
            <div style="text-align: center;">
                <button type="submit">Book Appointment</button>
            </div>
        </form>

        

        <div id="appointmentDisplay" style="display:none; margin-top:20px;">
            <h2>Appointments</h2>
            <table id="appointmentTable">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Child Name</th>
                        <th>Vaccine Name</th>
                        <th>Vaccine Dose</th>
                        <th>Date</th>
                        <th>Time</th>
                        <th>Center Name</th>
                        <th>Street</th>
                        <th>City</th>
                        <th>State</th>
                        <th>Pincode</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                </tbody>
            </table>
        </div>
    </div>
    <footer class="footer">

<div class="footer-container">
    <div class="footer-section contact-info">
        <h3>Contact Us</h3>
        <p><strong>Phone:</strong> +91-9876543210</p>
        <p><strong>Email:</strong> support@childvaccine.gov.in</p>
        <p><strong>Address:</strong> Ministry of Health & Family Welfare,<br>
            Government of India,<br>
            New Delhi - 110001</p>
    </div>

    <div class="footer-section quick-links">
        <h3>Quick Links</h3>
        <ul>
            <li><a href="home.php">Home</a></li>
            <li><a href="aboutus.html">About Us</a></li>
            <li><a href="contactus.php">Contact Us</a></li>
            <li><a href="privacy.html">Privacy Policy</a></li>
            <li><a href="terms.html">Terms & Conditions</a></li>
        </ul>
    </div>

    <div class="footer-section follow-us">
        <h3>Follow Us</h3>
        <p>
            <a href="#">Facebook</a> | 
            <a href="#">Twitter</a> | 
            <a href="#">Instagram</a> | 
            <a href="#">YouTube</a>
        </p>
    </div>
</div>

<div class="footer-bottom">
    <p>&copy; 2025 Child Vaccination System. All rights reserved.</p>
</div>
</footer>

</body>
</html>
